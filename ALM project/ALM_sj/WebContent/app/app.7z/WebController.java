package com.learning.ppm.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.learning.ppm.model.entity.PortFolio;
import com.learning.ppm.model.entity.Project;
import com.learning.ppm.model.service.PortFolioService;
import com.learning.ppm.model.service.ProjectService;

@Controller
public class WebController 
{
	@Autowired
	private PortFolioService portfolioservice;
	
	@Autowired
	private ProjectService projectService;
	
	@RequestMapping(value="/portfoliodetail/{param}")
	public @ResponseBody ArrayList<PortFolio> portfolios(@PathVariable String param) 
	{						
		 return (ArrayList<PortFolio>) portfolioservice.showAllPortFolio();
	}
	
	@RequestMapping(value="/saveProject", method=RequestMethod.POST)
	public String submitProject(@RequestBody Project projectDetails)
	{
		System.out.println(projectDetails);
		projectService.addProject(projectDetails);
		return "";
	}
	
	@RequestMapping(value="/savePortfolio", method=RequestMethod.POST)
	public String submitPortfolio(@RequestBody PortFolio portFolio)
	{
		System.out.println(portFolio);
		portfolioservice.addPortFolio(portFolio);
		return "";
	}
	
}