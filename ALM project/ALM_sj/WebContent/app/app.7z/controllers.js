'use strict';

/* Controllers */

angular.module('project.controllers',[]).
controller('ProjectList', ["portfolioService","$scope", "$http", function(portfolioService,$scope, $http) {
	$scope.portfolios=portfolioService.getPortfolios();
	
	$scope.sortTable = function(col) {
        $scope.sortOn = col;
    };
    
    $scope.deleteProject = function(id) {
        
    };
}]).
controller('addProjectCtrl',["portfolioService","$scope", "$http", function(portfolioService,$scope, $http) {
	$scope.portfolios=portfolioService.getPortfolios();
	$scope.pms = [];
	$scope.clientpocs = [];
	$scope.cons = [];
	$scope.submitProject = function() {
		$http.post('saveProject',$scope.project).success(function () {
			//Do Something
		});
	};
	
	$scope.addManagersForm = function() {
		
		$scope.pms.push(angular.copy($scope.pm));
		$scope.pm = {};
	};
	
	$scope.addClientPOCForm = function() {
		
		$scope.clientpocs.push(angular.copy($scope.clientpoc));
		$scope.clientpoc = {};
	};
	
	$scope.addConsultantForm = function() {
		
		$scope.cons.push(angular.copy($scope.con));
		$scope.con = {};
	};
	
	$scope.submitProject = function() {
		$scope.project.projectManagers = $scope.pms;
		$scope.project.clientPOC = $scope.clientpocs;
		$scope.project.consultant = $scope.cons;
		$scope.project.portfolio = $scope.portfolios[0];
		
		console.log(JSON.stringify($scope.project));
		$http.post('saveProject',$scope.project).success(function () {
			//Do Something
		});
	};
	
}]).
controller('addPortfolioCtrl',["$scope", "$http", function($scope, $http) {
	$scope.submitPortFolio = function() {
		console.log($scope.portFolio);
		$http.post('savePortfolio',$scope.portFolio).success(function () {
			//Do Something
		});
	};
	
}]);