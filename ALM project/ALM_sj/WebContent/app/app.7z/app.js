'use strict';

angular.module('project', ['ngRoute',
                           'project.services',
                           'project.controllers']).
config(['$routeProvider',function($routeProvider) {
    $routeProvider.
        when('/', {templateUrl: 'app/partials/home.html',controller: 'ProjectList'}).
    	when('/addProject', {templateUrl: 'app/partials/addProject.html',controller: 'addProjectCtrl'}).
    	when('/addPortfolio', {templateUrl: 'app/partials/addPortfolio.html',controller: 'addPortfolioCtrl'}).
    	when('/project/:pid', {templateUrl: 'app/partials/viewProject.html',controller: 'projectViewCtrl'});
}]);