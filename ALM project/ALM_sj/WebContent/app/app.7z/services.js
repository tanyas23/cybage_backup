'use strict';

/* Services */


// Demonstrate how to register services
// In this case it is a simple value service.
angular.module('project.services', []).
  service('portfolioService',function($http) {
	  var _portfolios = "";
	  
	  $http.get('portfoliodetail/all').success(function(data){
		  console.log(data);
	    	_portfolios=data;
	  });
	    
	  return {
		  getPortfolios:  function() {
			  return _portfolios;
		  }
	  };  
  });
